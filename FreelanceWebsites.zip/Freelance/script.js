document.addEventListener('DOMContentLoaded', () => {
    // Smooth scroll for nav links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });
  
    // Back to Top button
    const backToTop = document.getElementById("backToTop");
    window.addEventListener("scroll", () => {
      backToTop.style.display = window.scrollY > 300 ? "block" : "none";
    });
    backToTop.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  
    // Typewriter effect in hero
    const heroText = document.querySelector('.hero h2');
    const typeText = "Hello, I'm a Freelancer";
    let i = 0;
  
    function typeWriter() {
      if (i < typeText.length) {
        heroText.textContent += typeText.charAt(i);
        i++;
        setTimeout(typeWriter, 50);
      }
    }
  
    if (heroText) {
      heroText.textContent = "";
      typeWriter();
    }
  
    // Scroll reveal effect
    const revealEls = document.querySelectorAll('section');
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    }, { threshold: 0.1 });
  
    revealEls.forEach(el => {
      el.classList.add('reveal');
      observer.observe(el);
    });
  });
  